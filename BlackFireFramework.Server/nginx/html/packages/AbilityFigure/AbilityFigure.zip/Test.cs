﻿using Lyz.Func;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Lyz.Test
{
    public class Test : MonoBehaviour
    {
        AbilityFigure abilityFigure;
        private void Start()
        {
            abilityFigure = this.GetComponent<AbilityFigure>();
        }
        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.B))
            {
                abilityFigure.AddDotFunc("哈哈",1);
            }
            if(Input.GetKeyDown(KeyCode.M))
            {
                for (int i = 0; i < abilityFigure.GetDotInfo().Count; i++)
                {
                    abilityFigure.ChangeDotPropertyData(Random.Range(0,abilityFigure.GetDotInfo().Count), Random.Range(0f,1f));
                }
            }
            if (Input.GetKeyDown(KeyCode.C))
            {
                abilityFigure.ClearAll();
            }
            if (Input.GetKeyDown(KeyCode.P))
            {
                abilityFigure.PlayFunc();
            }
        }

    }
}