﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Lyz.Func
{
    public class AbilityFigure : Graphic
    {
        [SerializeField] float R = 100;
        [SerializeField] float offsetAngle=0;
        [SerializeField] List<DotProperty> Dot = new List<DotProperty>();
        [SerializeField] bool isPlay = false;
        [SerializeField] bool isShow = false;
        protected void Update()
        {
            if(Dot.Count>1)
            {
                RefreshPicture();
            }
            SetVerticesDirty();
        }
        
        #region 外部方法
        /// <summary>
        /// 添加一个属性
        /// </summary>
        /// <param name="name">属性名</param>
        /// <param name="value">属性值</param>
        public void AddDotFunc(string name,float value)
        {
            Dot.Add(new DotProperty(new DotPropertyData(name,value)));
            CalculateAllDotPos();
        }
        public List<DotProperty> GetDotInfo()
        {
            return Dot;
        }
        /// <summary>
        /// 改变某个属性的属性值大小
        /// </summary>
        /// <param name="name">属性名</param>
        /// <param name="powerValue">属性值大小</param>
        public void ChangeDotPropertyData(string name, float powerValue)
        {
            for (int i = 0; i < Dot.Count; i++)
            {
                if (Dot[i].dotPropertyData.name == name)
                {
                    DotPropertyData temp = new DotPropertyData(name,powerValue);
                    Dot[i].dotPropertyData = temp;
                }
            }
        }
        /// <summary>
        /// 通过属性名，改变某个属性的属性名称和属性值
        /// </summary>
        /// <param name="name">属性名</param>
        /// <param name="dotPropertyData">要修改的属性名和属性的值</param>
        public void ChangeDotPropertyData(string name , DotPropertyData dotPropertyData)
        {
            for (int i = 0; i < Dot.Count; i++)
            {
                if(Dot[i].dotPropertyData.name == name)
                {
                    Dot[i].dotPropertyData = dotPropertyData;
                }
            }
        }
        /// <summary>
        /// 通过点，改变某个属性的属性值
        /// </summary>
        /// <param name="index"></param>
        /// <param name="dotPropertyData"></param>
        public void ChangeDotPropertyData(int index, float value)
        {
            if (index > Dot.Count) return;
            Dot[index].dotPropertyData = new DotPropertyData(Dot[index].dotPropertyData.name, value);
        }
        /// <summary>
        /// 通过点，改变某个属性的属性名称和属性值
        /// </summary>
        /// <param name="index"></param>
        /// <param name="dotPropertyData"></param>
        public void ChangeDotPropertyData(int index, DotPropertyData dotPropertyData)
        {
            if (index > Dot.Count) return;
            Dot[index].dotPropertyData = dotPropertyData;
        }
        /// <summary>
        /// 删除某个属性
        /// </summary>
        /// <param name="name"></param>
        public void RemoveByName(string name)
        {
            for (int i = 0; i < Dot.Count; i++)
            {
                if(Dot[i].dotPropertyData.name==name)
                {
                    Dot.Remove(Dot[i]);
                }
            }
        }
        /// <summary>
        /// 清空所有点
        /// </summary>
        public void ClearAll()
        {
            Dot.Clear();
        }
        public void PlayFunc()
        {
            if (isPlay) return;
            StartCoroutine(PlayFuncIE());
        }
        #endregion
        #region 内部方法
        IEnumerator PlayFuncIE()
        {
            isShow = true;
            isPlay = true;
            List<float> tempDot = new List<float>();
            for (int i = 0; i < Dot.Count; i++)
            {
                tempDot.Add(Dot[i].dotPropertyData.Power);
                Dot[i].dotPropertyData.Power = 0;
            }
            float tempTime = 0;
            
            while (isPlay)
            {
                tempTime += Time.deltaTime;
                for (int i = 0; i < Dot.Count; i++)
                {
                    ChangeDotPropertyData(i, Mathf.Lerp(Dot[i].dotPropertyData.Power, tempDot[i], 5*Time.deltaTime));
                }
                yield return new WaitForFixedUpdate();
                if(tempTime>2)
                {
                    for (int i = 0; i < Dot.Count; i++)
                    {
                        ChangeDotPropertyData(i, tempDot[i]);
                    }
                    isPlay = false;
                }
            }
        }
       
        protected override void OnPopulateMesh(VertexHelper vh)
        {
            if (!isShow) return;
            vh.Clear();
            if (Dot.Count < 3) return;
            vh.AddVert(Vector3.zero, color, new Vector2(0, 0));
            for (int i = 0; i < Dot.Count; i++)
            {
                vh.AddVert(Dot[i].valuePos, color, new Vector2(0f, 0f));
            }
            for (int i = 0; i < Dot.Count - 1; i++)
            {
                vh.AddTriangle(0, i + 1, i + 2);
            }
            vh.AddTriangle(0, 1, Dot.Count);
        }
        private Vector3 PosOnCircle()
        {
            Vector3 vector3 = Vector3.zero;

            return vector3;
        }
        public void RefreshPicture()
        {
            CalculateAllDotPos();
            CalculateValuePos();
        }
        private void CalculateValuePos()
        {
            for (int i = 0; i < Dot.Count; i++)
            {
                Dot[i].valuePos = (Vector3.zero + Dot[i].peak) * Dot[i].dotPropertyData.Power;
            }
        }
        private void CalculateAllDotPos()
        {
            float offsetAngle_rad = Mathf.Deg2Rad * offsetAngle;
            float ang = Mathf.Deg2Rad * (360 / Dot.Count);
            Dot[0].peak = new Vector3(R * Mathf.Cos(offsetAngle_rad), R * Mathf.Sin(offsetAngle_rad), 0);
            for (int i = 0; i < Dot.Count; i++)
            {
                if (i == 0) continue;
                Dot[i].peak = new Vector3(R * Mathf.Cos(ang * i + offsetAngle_rad), R * Mathf.Sin(ang * i + offsetAngle_rad), 0);
            }
        }
        #endregion
    }
    [System.Serializable]
    public class DotPropertyData
    {
        public string name;
        [Range(0, 1)]
        [SerializeField] private float power;
        public float Power
        {
            get { return power; }
            set
            {
                if (value > 1)
                    power = 1;
                else
                {
                    power = value;
                }
            }
        }
        public DotPropertyData(string name,float value)
        {
            this.name = name;
            Power = value;
        }
    }
    [System.Serializable]
    public class DotProperty
    {
        [SerializeField] public Vector3 peak;
        [HideInInspector]public Vector3 valuePos;
        public DotPropertyData dotPropertyData;
        public DotProperty(DotPropertyData dotPropertyData)
        {
            this.dotPropertyData = dotPropertyData;
        }
    }
}